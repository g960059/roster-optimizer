import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='g960059',
    application_name='wariful',
    app_uid='WJ0Z3gMF6XW6vSKnkz',
    org_uid='xL1cggpRwKD6KGMGRM',
    deployment_uid='9a106f0b-ab5b-4198-aff8-72e2e3b4583c',
    service_name='roster-optimizer',
    stage_name='dev',
    plugin_version='3.3.0'
)
handler_wrapper_kwargs = {'function_name': 'roster-optimizer-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
