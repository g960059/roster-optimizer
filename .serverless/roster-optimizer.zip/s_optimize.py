import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='g960059',
    application_name='wariful',
    app_uid='WJ0Z3gMF6XW6vSKnkz',
    org_uid='xL1cggpRwKD6KGMGRM',
    deployment_uid='b4943801-a95f-41c7-a559-3ae28369d3fe',
    service_name='roster-optimizer',
    stage_name='dev',
    plugin_version='3.3.0'
)
handler_wrapper_kwargs = {'function_name': 'roster-optimizer-dev-optimize', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.optimize')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
