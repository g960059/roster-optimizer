import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='g960059',
    application_name='wariful-optimizer',
    app_uid='DZx18mMQDpdF6JLwXF',
    org_uid='xL1cggpRwKD6KGMGRM',
    deployment_uid='9e8ca281-165d-4afa-9587-dfe364274952',
    service_name='roster-optimizer',
    stage_name='dev',
    plugin_version='3.3.0'
)
handler_wrapper_kwargs = {'function_name': 'roster-optimizer-dev-optimize', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.optimize')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
